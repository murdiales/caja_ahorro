<?php

namespace App\Repository;

use App\Entity\InterestRateConfig;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<InterestRateConfig>
 */
class InterestRateConfigRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, InterestRateConfig::class);
    }

    //    /**
    //     * @return InterestRateConfig[] Returns an array of InterestRateConfig objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('i')
    //            ->andWhere('i.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('i.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?InterestRateConfig
    //    {
    //        return $this->createQueryBuilder('i')
    //            ->andWhere('i.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }

public function findActiveRate(
    \DateTimeInterface $date
): ?InterestRateConfig
{
    return $this->createQueryBuilder('r')
        ->andWhere('r.startDate <= :date')
        ->andWhere(
            '(r.endDate IS NULL OR r.endDate >= :date)'
        )
        ->setParameter('date', $date)
        ->orderBy('r.startDate', 'DESC')
        ->setMaxResults(1)
        ->getQuery()
        ->getOneOrNullResult();
}

}
