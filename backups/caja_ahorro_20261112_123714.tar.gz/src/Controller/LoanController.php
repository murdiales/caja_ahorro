<?php

namespace App\Controller;

use App\Entity\Loan;
use App\Repository\AccountRepository;
use App\Repository\LoanRepository;
use App\Repository\LoanInstallmentRepository;
use App\Service\TransactionService;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Email;
use Symfony\Component\Routing\Attribute\Route;
use App\Service\LoanRequestService;

#[Route('/loan')]
final class LoanController extends AbstractController
{
    /**
     * 1. FORMULARIO DE SOLICITUD DE PRÉSTAMO
     */
    #[Route('/request', name: 'app_loan_request', methods: ['GET', 'POST'])]
    public function requestLoan(
        Request $request,
        AccountRepository $accountRepository,
        EntityManagerInterface $em,
        LoanRequestService $loanRequestService
    ): Response {
        if (!$this->getUser()) {
            return $this->redirectToRoute('app_login');
        }

        $selectedAccountId = $request->query->get('account_id');

        if (
            $this->isGranted('ROLE_ADMIN')
            || $this->isGranted('ROLE_TESORERO')
        ) {

            $accounts = $accountRepository->findAll();

        } else {

            $accounts = $accountRepository->findBy([
                'user' => $this->getUser()
            ]);

        }

        if ($request->isMethod('POST')) {
            $accountId = $request->request->get('account_id');
            $amount = (float) $request->request->get('amount');
            $termMonths = (int) $request->request->get('term_months');
            $interestRate = 12.0; // Tasa de interés anual fija (12%)

            // Validación del plazo (Máximo 60 meses)
            if ($termMonths < 1 || $termMonths > 60) {
                $this->addFlash('danger', 'El plazo debe ser entre 1 y 60 meses.');
                return $this->redirectToRoute('app_loan_request', ['account_id' => $accountId]);
            }

            $account = $accountRepository->find($accountId);
            if (
                !$this->isGranted('ROLE_ADMIN')
                && !$this->isGranted('ROLE_TESORERO')
            ) {

                if (
                    !$account
                    || !$account->getUser()
                    || $account->getUser()->getId() !== $this->getUser()->getId()
                ) {

                   $this->addFlash(
                        'danger',
                        'No puede solicitar préstamos para cuentas de otros socios.'
                    );

                    return $this->redirectToRoute(
                        'app_loan_request'
                    );
                }

            if (!$account) {
                $this->addFlash('danger', 'La cuenta seleccionada no existe.');
            } 

                // Cálculo de cuota estimada amortizada
                $monthlyInterest = ($interestRate / 100) / 12;
                $monthlyFee = ($amount * $monthlyInterest) / (1 - pow(1 + $monthlyInterest, -$termMonths));

        $firstDueDate = (new DateTimeImmutable())->modify("+1 month");
        try {
            $loan = $loanRequestService->create(
                $account,
                (float) $amount,
                $termMonths,
                (float) $interestRate,
                $firstDueDate
            );
        } catch (\Throwable $e) {
            die($e->getMessage());
        }
        $this->addFlash('success', '✅ ¡TU SOLICITUD HA SIDO ENVIADA CON ÉXITO! Su solicitud se encuentra pendiente de revisión y aprobación.');
                return $this->redirectToRoute('app_loan_pending');
            }
        }

        return $this->render('loan/request.html.twig', [
            'accounts' => $accounts,
            'selectedAccountId' => $selectedAccountId,
        ]);
    }

    /**
     * 2. BANDEJA DE SOLICITUDES Y APROBACIONES
     */
    #[Route('/pending', name: 'app_loan_pending', methods: ['GET'])]
    public function pendingLoans(LoanRepository $loanRepository): Response
    {
        if (!$this->getUser()) {
            return $this->redirectToRoute('app_login');
        }

        $pendingLoans = $loanRepository->findBy(['status' => 'SOLICITADO'], ['requestDate' => 'DESC']);

        return $this->render('loan/pending.html.twig', [
            'loans' => $pendingLoans,
        ]);
    }

    /**
     * ACCIÓN DE APROBAR PRÉSTAMO Y ENVIAR NOTIFICACIÓN POR CORREO
     */
    #[Route('/{id}/approve', name: 'app_loan_approve', methods: ['POST'])]
    public function approveLoan(
        Loan $loan,
        TransactionService $transactionService,
        EntityManagerInterface $em,
        LoanRequestService $loanRequestService,
        MailerInterface $mailer
    ): Response {
        if (!$this->getUser()) {
            return $this->redirectToRoute('app_login');
        }

        if ($loan->getStatus() !== 'SOLICITADO') {
            $this->addFlash('warning', 'Esta solicitud ya fue procesada.');
            return $this->redirectToRoute('app_loan_pending');
        }

        try {
            // 1. Cambiar estado a Aprobado
            $loan->setStatus('APROBADO');
            $loan->setApprovalDate(new \DateTimeImmutable());
            $em->flush();

            // 2. Acreditar monto del préstamo a la cuenta del socio
            $transactionService->deposit(
                $loan->getAccount(),
                (float) $loan->getAmount(),
                sprintf('Desembolso por Aprobación de Préstamo #%d', $loan->getId())
            );

            // 3. Enviar correo de aprobación
            $user = $loan->getAccount()->getUser();
            $email = (new Email())
                ->from('no-reply@caja-ahorro.com')
                ->to($user->getEmail())
                ->subject(sprintf('¡Su Préstamo #%d ha sido APROBADO!', $loan->getId()))
                ->html($this->renderView('email/loan_approved.html.twig', [
                    'loan' => $loan,
                ]));

            try {
                $mailer->send($email);
            } catch (\Throwable $e) {
            }

            $this->addFlash('success', sprintf('¡Préstamo #%d aprobado y acreditado correctamente!', $loan->getId()));
        } catch (Exception $e) {
            $this->addFlash('danger', 'Error al procesar la aprobación: ' . $e->getMessage());
        }

        return $this->redirectToRoute('app_loan_pending');
    }

    /**
     * ACCIÓN DE RECHAZAR PRÉSTAMO Y ENVIAR NOTIFICACIÓN POR CORREO
     */
    #[Route('/{id}/reject', name: 'app_loan_reject', methods: ['POST'])]
    public function rejectLoan(
        Loan $loan,
        EntityManagerInterface $em,
        LoanRequestService $loanRequestService,
        MailerInterface $mailer
    ): Response {
        if (!$this->getUser()) {
            return $this->redirectToRoute('app_login');
        }

        if ($loan->getStatus() !== 'SOLICITADO') {
            $this->addFlash('warning', 'Esta solicitud ya fue procesada.');
            return $this->redirectToRoute('app_loan_pending');
        }

        try {
            // 1. Cambiar estado a Rechazado
            $loan->setStatus('RECHAZADO');
            $em->flush();

            // 2. Enviar correo de notificación de rechazo
            $user = $loan->getAccount()->getUser();
            $email = (new Email())
                ->from('no-reply@caja-ahorro.com')
                ->to($user->getEmail())
                ->subject(sprintf('Notificación sobre su Solicitud de Préstamo #%d', $loan->getId()))
                ->html($this->renderView('email/loan_rejected.html.twig', [
                    'loan' => $loan,
                ]));

            try {
                $mailer->send($email);
            } catch (\Throwable $e) {
            }
            $this->addFlash('info', sprintf('La solicitud de préstamo #%d ha sido rechazada y notificada.', $loan->getId()));
        } catch (Exception $e) {
            $this->addFlash('danger', 'Error al procesar el rechazo: ' . $e->getMessage());
        }

        return $this->redirectToRoute('app_loan_pending');
    }

    /**
     * 3. HISTORIAL GENERAL DE PRÉSTAMOS
     */
    #[Route('/history', name: 'app_loan_history', methods: ['GET'])]
    public function history(LoanRepository $loanRepository): Response
    {
        if (!$this->getUser()) {
            return $this->redirectToRoute('app_login');
        }

        if (
            $this->isGranted('ROLE_ADMIN')
            || $this->isGranted('ROLE_TESORERO')
        ) {

            $loans = $loanRepository->findBy([], [
                'requestDate' => 'DESC'
            ]);

        } else {

            $loans = array_filter(
                $loanRepository->findBy([], ['requestDate' => 'DESC']),
                fn($loan) => $loan->getAccount()
                    && $loan->getAccount()->getUser()
                    && $loan->getAccount()->getUser()->getId() === $this->getUser()->getId()
            );

        }

        return $this->render('loan/history.html.twig', [
            'loans' => $loans,
        ]);
    }

    /**
     * 4. CONTROL Y TABLA DE PAGOS
     */
    #[Route('/payments', name: 'app_loan_payments', methods: ['GET'])]
    public function payments(Request $request, LoanRepository $loanRepository): Response
    {
        if (!$this->getUser()) {
            return $this->redirectToRoute('app_login');
        }

        $period = $request->query->get('period', 'all');

        $approvedLoans = $loanRepository->findBy(
            ['status' => 'APROBADO'],
            ['approvalDate' => 'DESC']
        );

        if ($period !== 'all') {

            $fromDate = match ($period) {
                '3m' => new \DateTime('-3 months'),
                '6m' => new \DateTime('-6 months'),
                '1y' => new \DateTime('-1 year'),
                default => null
            };

            if ($fromDate) {
                $approvedLoans = array_filter(
                    $approvedLoans,
                    fn($loan) =>
                        $loan->getApprovalDate()
                        && $loan->getApprovalDate() >= $fromDate
                );
            }
        }

        $totalLoans = count($approvedLoans);

        $totalAmount = 0;
        $totalInterest = 0;

        foreach ($approvedLoans as $loan) {
            $totalAmount += (float) $loan->getAmount();
            $totalInterest += (float) ($loan->getTotalInterest() ?? 0);
        }

        return $this->render('loan/payments.html.twig', [
            'loans' => $approvedLoans,
            'period' => $period,
            'totalLoans' => $totalLoans,
            'totalAmount' => $totalAmount,
            'totalInterest' => $totalInterest,
        ]);
    }


    #[Route('/loan/{id}', name: 'loan_view')]
    #[Route('/loan/{id}', name: 'loan_view')]
    public function viewLoan(Loan $loan): Response
    {
        return $this->render('loan/view.html.twig', [
            'loan' => $loan,
        ]);
    }

    #[Route('/loan/{id}/notify', name: 'loan_notify')]
    public function notifyLoan(Loan $loan): Response
    {
        return new Response(
            'Notificar préstamo #' . $loan->getId()
        );
    }
    #[Route('/loan/{id}/schedule', name: 'loan_schedule')]
    public function scheduleLoan(
        Loan $loan,
        LoanInstallmentRepository $installmentRepository
    ): Response
    {
        $installments = $installmentRepository->findBy([
            'loan' => $loan
        ]);

        return $this->render('loan/schedule.html.twig', [
            'loan' => $loan,
            'installments' => $installments,
        ]);
    }

    #[Route('/loan/{id}/pay', name: 'loan_pay')]
    public function payLoan(
        Loan $loan
    ): Response
    {
        return new Response(
            'Registrar pago préstamo #' . $loan->getId()
        );
    }

}
