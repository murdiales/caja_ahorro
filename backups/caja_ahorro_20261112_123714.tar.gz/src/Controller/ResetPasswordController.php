<?php

namespace App\Controller;

use App\Entity\User;
use App\Form\ChangePasswordFormType;
use App\Form\ResetPasswordRequestFormType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Mailer\MailerInterface;
use Symfony\Component\Mime\Address;
use Symfony\Component\Mime\Email;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Contracts\Translation\TranslatorInterface;
use SymfonyCasts\Bundle\ResetPassword\Controller\ResetPasswordControllerTrait;
use SymfonyCasts\Bundle\ResetPassword\Exception\ResetPasswordExceptionInterface;
use SymfonyCasts\Bundle\ResetPassword\ResetPasswordHelperInterface;

#[Route('/reset-password')]
class ResetPasswordController extends AbstractController
{
    use ResetPasswordControllerTrait;

    public function __construct(
        private ResetPasswordHelperInterface $resetPasswordHelper,
        private EntityManagerInterface $entityManager
    ) {
    }

    /**
     * Display & process form to request a password reset.
     */
    #[Route('', name: 'app_forgot_password_request')]
    public function request(Request $request, MailerInterface $mailer, TranslatorInterface $translator): Response
    {
        $form = $this->createForm(ResetPasswordRequestFormType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            /** @var string $email */
            $email = $form->get('email')->getData();

            return $this->processSendingPasswordResetEmail(
                $email,
                $mailer,
                $translator
            );
        }

        return $this->render('reset_password/request.html.twig', [
            'requestForm' => $form,
        ]);
    }

    /**
     * Confirmation page after a user has requested a password reset.
     */
    #[Route('/check-email', name: 'app_check_email')]
    public function checkEmail(): Response
    {
        if (null === ($resetToken = $this->getTokenObjectFromSession())) {
            $resetToken = $this->resetPasswordHelper->generateFakeResetToken();
        }

        return $this->render('reset_password/check_email.html.twig', [
            'resetToken' => $resetToken,
        ]);
    }

    /**
     * Validates and process the reset URL that the user clicked in their email.
     */
    #[Route('/reset/{token}', name: 'app_reset_password')]
    public function reset(Request $request, UserPasswordHasherInterface $passwordHasher, TranslatorInterface $translator, ?string $token = null): Response
    {
        if ($token) {
            $this->storeTokenInSession($token);

            return $this->redirectToRoute('app_reset_password');
        }

        $token = $this->getTokenFromSession();

        if (null === $token) {
            throw $this->createNotFoundException('No reset password token found in the URL or in the session.');
        }

        try {
            /** @var User $user */
            $user = $this->resetPasswordHelper->validateTokenAndFetchUser($token);
        } catch (ResetPasswordExceptionInterface $e) {
            $this->addFlash('reset_password_error', sprintf(
                '%s - %s',
                $translator->trans(ResetPasswordExceptionInterface::MESSAGE_PROBLEM_VALIDATE, [], 'ResetPasswordBundle'),
                $translator->trans($e->getReason(), [], 'ResetPasswordBundle')
            ));

            return $this->redirectToRoute('app_forgot_password_request');
        }

        $form = $this->createForm(ChangePasswordFormType::class);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->resetPasswordHelper->removeResetRequest($token);

            /** @var string $plainPassword */
            $plainPassword = $form->get('plainPassword')->getData();

            $user->setPassword($passwordHasher->hashPassword($user, $plainPassword));
            $this->entityManager->flush();

            $this->cleanSessionAfterReset();

            return $this->redirectToRoute('app_login');
        }

        return $this->render('reset_password/reset.html.twig', [
            'resetForm' => $form,
        ]);
    }

    private function processSendingPasswordResetEmail(
        string $emailFormData,
        MailerInterface $mailer,
        TranslatorInterface $translator
    ): RedirectResponse {
        $user = $this->entityManager->getRepository(User::class)->findOneBy([
            'email' => $emailFormData,
        ]);

        if (!$user) {
            file_put_contents(
                '/tmp/reset_debug.log',
                date('Y-m-d H:i:s') . " USUARIO_NO_ENCONTRADO: " . $emailFormData . "\n",
                FILE_APPEND
            );

            return $this->redirectToRoute('app_check_email');
        }

        try {
            file_put_contents(
                '/tmp/reset_debug.log',
                date('Y-m-d H:i:s') . " INICIO_RESET\n",
                FILE_APPEND
            );

            $resetToken = $this->resetPasswordHelper->generateResetToken($user);

            file_put_contents(
                '/tmp/reset_debug.log',
                date('Y-m-d H:i:s') . " TOKEN_GENERADO\n",
                FILE_APPEND
            );

            $resetUrl = 'https://caja.benditotrabajo.com/reset-password/reset/' . $resetToken->getToken();

            file_put_contents(
                '/tmp/reset_debug.log',
                date('Y-m-d H:i:s') . " URL_GENERADA: " . $resetUrl . "\n",
                FILE_APPEND
            );

            $email = (new Email())
                ->from(new Address('chiribanks@gmail.com', 'Caja de Ahorro'))
                ->to((string) $user->getEmail())
                ->subject('Restablecimiento de contraseña - Caja de Ahorro')
                ->text(
                    "Hola,\n\n" .
                    "Para restablecer tu contraseña ingresa al siguiente enlace:\n\n" .
                    $resetUrl .
                    "\n\nEste enlace expirará en 1 hora."
                );

            file_put_contents(
                '/tmp/reset_debug.log',
                date('Y-m-d H:i:s') . " ANTES_SEND: " . $user->getEmail() . "\n",
                FILE_APPEND
            );

            $mailer->send($email);

            file_put_contents(
                '/tmp/reset_debug.log',
                date('Y-m-d H:i:s') . " DESPUES_SEND\n",
                FILE_APPEND
            );

            $this->setTokenObjectInSession($resetToken);

            file_put_contents(
                '/tmp/reset_debug.log',
                date('Y-m-d H:i:s') . " TOKEN_GUARDADO\n",
                FILE_APPEND
            );

        } catch (\Throwable $e) {
            file_put_contents(
                '/tmp/reset_debug.log',
                date('Y-m-d H:i:s') . " ERROR: " . $e->getMessage() . "\n",
                FILE_APPEND
            );

            throw $e;
        }

        return $this->redirectToRoute('app_check_email');
    }
}
